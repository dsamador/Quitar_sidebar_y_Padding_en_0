coso = document.getElementById("courseSidebar")

setTimeout(()=>{
    coso.remove()
}, 4000)